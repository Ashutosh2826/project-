# Vehicle-Parking-Management-System
Vehicle Parking Management System is a project to demonstrate the managing of Vehicle Parking for Parking management team.

## Installation


```bash
1. Download the zip file
2. Extract the file and copy the vpms folder
3.Paste inside root directory(for xampp xampp/htdocs inside htdocs paste the vpms folder)
4. Open PHPMyAdmin (http://localhost/phpmyadmin)
5. Create a database with name vpmsdb
6. Import vpmsdb.sql file(given inside the zip package in sql file folder)
7.Run the script http://localhost/Vehicle-parking-management-System-project/Vehicle-parking-management-System-project/vpms/ (frontend)
```

## UI WorkFlow

Login Page

![Screenshot_1](https://user-images.githubusercontent.com/91688610/152656355-0aacab5b-636d-4c45-8b34-c9bc8ae2b393.png)


Dashboard Page


![Screenshot_2](https://user-images.githubusercontent.com/91688610/152656544-556d0cc9-b61e-4414-9a6a-295bdc91fc56.png)


Vehicle Adding Page

![Screenshot_4](https://user-images.githubusercontent.com/91688610/152656568-5d87e66d-8fa2-429c-a932-cea5bcbbec6e.png)


Added Vehicles Managing

![Screenshot_3](https://user-images.githubusercontent.com/91688610/152656636-d5e872f9-31cc-4324-b7bc-db3369ec81fc.png)

Printed Receipt for Users

![Screenshot_5](https://user-images.githubusercontent.com/91688610/152656727-39dccd04-5019-49b3-9cb3-5d2ecff908a6.png)

